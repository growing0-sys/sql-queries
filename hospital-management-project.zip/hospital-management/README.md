# 🏥 Hospital Management System – SQL Project

This SQL project manages and analyzes hospital data using structured queries. It includes patients, doctors, and appointment details.

## 📁 Files
- `schema.sql` – Table definitions for Patients, Doctors, and Appointments.
- `data.sql` – Sample data to populate the tables.
- `queries.sql` – SQL queries to fetch useful insights.

## 📊 Features
- View all appointments
- Track which patients visited which doctor
- Count appointments per doctor
- Find latest appointment date

## 🛠️ Skills Used
- SQL (CREATE, INSERT, SELECT)
- JOINs and GROUP BY
- Filtering and sorting

## ✅ Progress

| Task                          | Status        |
|-------------------------------|---------------|
| Create schema                 | ✅ Done        |
| Add sample data               | ✅ Done        |
| Write basic queries           | ✅ Done        |
| Upload to GitHub              | 🔄 In Progress |
| Expand with JOINs, filters    | 🔲 To Do       |
