-- 1. List all appointments
SELECT * FROM Appointments;

-- 2. Get all patients who visited Dr. Neha Jain
SELECT p.name, a.appointment_date, a.diagnosis
FROM Appointments a
JOIN Patients p ON a.patient_id = p.patient_id
JOIN Doctors d ON a.doctor_id = d.doctor_id
WHERE d.name = 'Dr. Neha Jain';

-- 3. Count number of appointments per doctor
SELECT d.name, COUNT(*) AS total_appointments
FROM Appointments a
JOIN Doctors d ON a.doctor_id = d.doctor_id
GROUP BY d.name;

-- 4. Find the latest appointment
SELECT * FROM Appointments
ORDER BY appointment_date DESC
LIMIT 1;
