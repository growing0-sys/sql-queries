-- Patients
INSERT INTO Patients VALUES
(1, 'Amit Sharma', 'Male', '1990-05-10', '9876543210'),
(2, 'Sonal Verma', 'Female', '1985-03-22', '9823456789'),
(3, 'Rahul Mehta', 'Male', '2000-12-01', '9988776655');

-- Doctors
INSERT INTO Doctors VALUES
(101, 'Dr. Neha Jain', 'Cardiology', '9012345678'),
(102, 'Dr. Arjun Roy', 'Neurology', '9023456789');

-- Appointments
INSERT INTO Appointments VALUES
(1001, 1, 101, '2025-06-15', 'Chest pain'),
(1002, 2, 102, '2025-06-16', 'Migraine'),
(1003, 3, 101, '2025-06-17', 'Irregular heartbeat');
